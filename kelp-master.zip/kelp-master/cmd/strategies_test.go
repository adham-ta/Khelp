package cmd

import (
	"testing"
)

func TestStrategies(t *testing.T) {
	strategiesCmd.Run(nil, nil)
}
