package cmd

import (
	"testing"
)

func TestExchanges(t *testing.T) {
	exchangesCmd.Run(nil, nil)
}
