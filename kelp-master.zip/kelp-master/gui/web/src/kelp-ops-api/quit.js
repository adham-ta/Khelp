export default (baseUrl) => {
    return fetch(baseUrl + "/api/v1/quit");
};