package backend

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os/exec"
	"strings"

	"github.com/stellar/kelp/gui/model2"
	"github.com/stellar/kelp/support/kelpos"
)

func (s *APIServer) startBot(w http.ResponseWriter, r *http.Request) {
	botNameBytes, e := ioutil.ReadAll(r.Body)
	if e != nil {
		s.writeError(w, fmt.Sprintf("error when reading request input: %s\n", e))
		return
	}

	botName := string(botNameBytes)
	e = s.doStartBot(botName, "buysell", nil, nil)
	if e != nil {
		s.writeError(w, fmt.Sprintf("error starting bot: %s\n", e))
		return
	}

	e = s.kos.AdvanceBotState(botName, kelpos.BotStateStopped)
	if e != nil {
		s.writeError(w, fmt.Sprintf("error advancing bot state: %s\n", e))
		return
	}

	w.WriteHeader(http.StatusOK)
}

func (s *APIServer) doStartBot(botName string, strategy string, iterations *uint8, maybeFinishCallback func()) error {
	filenamePair := model2.GetBotFilenames(botName, strategy)
	logPrefix := model2.GetLogPrefix(botName, strategy)

	// config files and log prefix under linux subsystem:
	// - unix relative paths did work on windows!
	// - native relative paths did not work on windows for config files but worked for log prefixes!
	// - native absolute paths did not work on windows
	// - unix absolute path did not work on windows
	//
	// config files and log prefix invoked without bash -c (i.e. not under linux system):
	// - unix relative paths did work on windows!
	// - native relative paths did work on windows!
	// - native absolute paths did work on windows!
	// - unix absolute path did not work on windows
	//
	// (see api_server.go#runKelpCommandBlocking and #runKelpCommandBackground for information that may be related to why
	// absolute paths did not work)
	//
	// The above experimentation makes unix relative paths the most common format so we will use that to start new bots
	//
	// Note that on windows it could use the native windows naming scheme (C:\ etc.) but in the linux subsystem on windows
	// there is no C:\ but instead is listed as /mnt/c/... so we need to convert from unix to windows (/mnt/c -> C:\) or
	// use relative paths, which is why it seems to work
	// Note that /mnt/c is unlikely to be valid in windows (but is valid in the linux subsystem) since it's usually prefixed by the
	// volume (C:\ etc.), which is why relative paths works so well here as it avoids this confusion.
	traderRelativeConfigPath, e := s.botConfigsPath.Join(filenamePair.Trader).RelFromPath(s.kos.GetDotKelpWorkingDir())
	if e != nil {
		return fmt.Errorf("unable to get relative path of trader config file from basepath: %s", e)
	}

	stratRelativeConfigPath, e := s.botConfigsPath.Join(filenamePair.Strategy).RelFromPath(s.kos.GetDotKelpWorkingDir())
	if e != nil {
		return fmt.Errorf("unable to get relative path of strategy config file from basepath: %s", e)
	}

	logRelativePrefixPath, e := s.botLogsPath.Join(logPrefix).RelFromPath(s.kos.GetDotKelpWorkingDir())
	if e != nil {
		return fmt.Errorf("unable to get relative path of log prefix path from basepath: %s", e)
	}

	command := fmt.Sprintf("trade -c %s -s %s -f %s -l %s --ui",
		traderRelativeConfigPath.Unix(),
		strategy,
		stratRelativeConfigPath.Unix(),
		logRelativePrefixPath.Unix(),
	)
	if iterations != nil {
		command = fmt.Sprintf("%s --iter %d", command, *iterations)
	}
	if s.noHeaders {
		command = fmt.Sprintf("%s --no-headers", command)
	}
	if s.ccxtRestUrl != "" {
		command = fmt.Sprintf("%s --ccxt-rest-url %s", command, s.ccxtRestUrl)
	}
	log.Printf("run command for bot '%s': %s\n", botName, command)

	p, e := s.runKelpCommandBackground(botName, command)
	if e != nil {
		return fmt.Errorf("could not start bot %s: %s", botName, e)
	}

	go func(kelpCommand *exec.Cmd, name string) {
		defer s.kos.SafeUnregister(name)

		if kelpCommand == nil {
			log.Printf("kelpCommand was nil for bot '%s' with strategy '%s'\n", name, strategy)
			return
		}

		e := kelpCommand.Wait()
		if e != nil {
			if strings.Contains(e.Error(), "signal: terminated") {
				log.Printf("terminated start bot command for bot '%s' with strategy '%s'\n", name, strategy)
				return
			}
			log.Printf("error when starting bot '%s' with strategy '%s': %s\n", name, strategy, e)
			return
		}

		log.Printf("finished start bot command for bot '%s' with strategy '%s'\n", name, strategy)
		if maybeFinishCallback != nil {
			maybeFinishCallback()
		}
	}(p.Cmd, botName)

	return nil
}
